public class Cell {

    LLAddOnly head;
    Cell next;

    Wall down;
    Wall up;
    Wall left;
    Wall right;

}